-- 46 Prediction: initial PostgreSQL schema for Supabase.
-- Run in Supabase SQL Editor as the project owner.
-- Browser clients receive no table policies; all writes must go through the server.

create extension if not exists pgcrypto;

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  username text not null,
  username_normalized text generated always as (lower(trim(username))) stored,
  recovery_code_hash text not null,
  diamonds integer not null default 500 check (diamonds >= 0),
  energy integer not null default 120 check (energy >= 0),
  status text not null default 'active' check (status in ('active', 'suspended', 'deleted')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint users_username_nonempty check (length(trim(username)) between 2 and 32),
  constraint users_username_unique unique (username_normalized)
);

create table if not exists public.admins (
  user_id uuid primary key references public.users(id) on delete cascade,
  role text not null check (role in ('owner', 'admin', 'moderator', 'content_manager')),
  created_at timestamptz not null default now()
);

create table if not exists public.predictions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  category text not null default 'Autre',
  image_url text,
  source_url text,
  yes_label text not null default 'Oui',
  no_label text not null default 'Non',
  closes_at timestamptz,
  min_diamonds integer not null default 1 check (min_diamonds >= 1),
  energy_per_diamond numeric(8,2) not null default 1 check (energy_per_diamond >= 0),
  status text not null default 'open' check (status in ('draft', 'open', 'resolved', 'cancelled')),
  outcome text check (outcome in ('yes', 'no')),
  created_by uuid references public.users(id) on delete set null,
  resolved_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  constraint predictions_title_nonempty check (length(trim(title)) between 3 and 240),
  constraint predictions_outcome_status check (outcome is null or status = 'resolved')
);

create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  prediction_id uuid not null references public.predictions(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  choice text not null check (choice in ('yes', 'no')),
  diamonds integer not null check (diamonds >= 1),
  created_at timestamptz not null default now(),
  constraint votes_one_per_user_prediction unique (prediction_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  prediction_id uuid not null references public.predictions(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  body text not null,
  status text not null default 'visible' check (status in ('visible', 'hidden', 'removed')),
  created_at timestamptz not null default now(),
  constraint comments_body_length check (length(trim(body)) between 1 and 2000)
);

create table if not exists public.comment_likes (
  comment_id uuid not null references public.comments(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null default '',
  image_url text,
  video_url text,
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint announcements_title_nonempty check (length(trim(title)) between 1 and 160)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  announcement_id uuid references public.announcements(id) on delete cascade,
  kind text not null default 'announcement',
  title text not null,
  message text not null default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  currency text not null check (currency in ('diamonds', 'energy')),
  amount integer not null check (amount <> 0),
  reason text not null check (reason in ('signup_bonus', 'prediction_stake', 'prediction_reward', 'energy_exchange', 'share_bonus', 'admin_adjustment', 'refund')),
  prediction_id uuid references public.predictions(id) on delete set null,
  reference_id uuid,
  created_by uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists predictions_status_created_idx on public.predictions(status, created_at desc);
create index if not exists predictions_category_status_idx on public.predictions(category, status);
create index if not exists votes_user_created_idx on public.votes(user_id, created_at desc);
create index if not exists votes_prediction_idx on public.votes(prediction_id);
create index if not exists comments_prediction_created_idx on public.comments(prediction_id, created_at desc);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists wallet_transactions_user_created_idx on public.wallet_transactions(user_id, created_at desc);

alter table public.users enable row level security;
alter table public.admins enable row level security;
alter table public.predictions enable row level security;
alter table public.votes enable row level security;
alter table public.comments enable row level security;
alter table public.comment_likes enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.admin_audit_log enable row level security;

-- No policies are created on purpose. Public browser requests are denied until
-- authenticated server routes and their authorization rules are implemented.
